import React, { useState } from "react";
import {
  BarChart3, Check, Compass, FileText, Flag, Settings, ShieldCheck, Star,
  Trash2, TrendingUp, Users, Wallet, X
} from "lucide-react";
import { Avatar, Stat, Rating, StatusPill, SectionTitle, EmptyState, Field } from "./ui.jsx";
import { platformUsers, seedVerifications, seedReviews } from "./data.js";

const TABS = [
  ["overview", "Overview", BarChart3],
  ["users", "Users", Users],
  ["verify", "Verification", ShieldCheck],
  ["projects", "Projects", Compass],
  ["quotes", "Quotes", Wallet],
  ["reviews", "Reviews", Star],
  ["reports", "Reports", FileText],
  ["settings", "Settings", Settings],
];

export function AdminPanel({ store, notify }) {
  const [tab, setTab] = useState("overview");
  const [queue, setQueue] = useState(seedVerifications);
  const [users, setUsers] = useState(platformUsers);
  const [reviews, setReviews] = useState(seedReviews);

  const decide = (id, ok) => {
    const person = queue.find(q => q.id === id);
    setQueue(queue.filter(q => q.id !== id));
    setUsers(us => us.map(u => u.name === person.name ? { ...u, status: ok ? "Verified" : "Rejected" } : u));
    notify(ok ? `${person.name} verified` : `${person.name} rejected`);
  };

  return <section className="section page-section">
    <SectionTitle eyebrow="Administration" title="Admin dashboard"
      text="Monitor users, projects, verification, quotes and reports."/>

    <div className="tabbar scroll">
      {TABS.map(([k, label, Icon]) => (
        <button className={tab === k ? "on" : ""} key={k} onClick={() => setTab(k)}><Icon size={15}/> {label}</button>
      ))}
    </div>

    {tab === "overview" && <>
      <div className="stats">
        <Stat icon={Users} label="Total users" value="1,284"/>
        <Stat icon={ShieldCheck} label="Pending verification" value={String(queue.length)}/>
        <Stat icon={Compass} label="Active projects" value="164"/>
        <Stat icon={Wallet} label="Quotes this month" value="427"/>
      </div>
      <div className="admin-grid">
        <div className="panel">
          <div className="panel-head"><h3>Verification queue</h3><span className="badge pending">{queue.length} waiting</span></div>
          {queue.length === 0
            ? <EmptyState icon={ShieldCheck} title="Queue is clear" text="Every submitted document has been reviewed."/>
            : queue.map(v => <div className="admin-row" key={v.id}>
                <Avatar initials={v.initials}/>
                <div><b>{v.name} — {v.role}</b><small>{v.docs} · {v.submitted}</small></div>
                <div className="row-actions">
                  <button className="outline ok" onClick={() => decide(v.id, true)}><Check size={14}/></button>
                  <button className="outline no" onClick={() => decide(v.id, false)}><X size={14}/></button>
                </div>
              </div>)}
        </div>
        <div className="panel">
          <h3>Platform activity</h3>
          <div className="activity"><b>42</b><span>new project requests</span></div>
          <div className="activity"><b>87</b><span>quotations submitted</span></div>
          <div className="activity"><b>31</b><span>new expert profiles</span></div>
          <div className="activity"><b>18</b><span>projects completed</span></div>
        </div>
      </div>
    </>}

    {tab === "users" && <div className="panel">
      <div className="panel-head"><h3>User management</h3><span className="badge ok">{users.length} accounts</span></div>
      <div className="table">
        <div className="tr th"><span>Name</span><span>Role</span><span>Location</span><span>Joined</span><span>Status</span><span></span></div>
        {users.map(u => <div className="tr" key={u.id}>
          <span className="cell-name"><Avatar initials={u.name.split(" ").map(w => w[0]).join("").slice(0, 2)}/><b>{u.name}</b></span>
          <span>{u.role}</span><span>{u.location}</span><span>{u.joined}</span>
          <span><em className={`badge ${u.status === "Verified" ? "ok" : u.status === "Rejected" ? "no" : "pending"}`}>{u.status}</em></span>
          <span><button className="outline small" onClick={() => notify(`${u.name} suspended`)}>Suspend</button></span>
        </div>)}
      </div>
    </div>}

    {tab === "verify" && <div className="panel">
      <div className="panel-head"><h3>Verify professionals &amp; students</h3><span className="badge pending">{queue.length} pending</span></div>
      {queue.length === 0
        ? <EmptyState icon={ShieldCheck} title="Nothing pending" text="All submitted documents have been actioned."/>
        : queue.map(v => <div className="verify-card" key={v.id}>
            <Avatar initials={v.initials} size={52}/>
            <div className="verify-main">
              <b>{v.name}</b><small>{v.role} · submitted {v.submitted}</small>
              <div className="pill-list">{v.docs.split(" · ").map(d => <span key={d}>{d}</span>)}</div>
            </div>
            <div className="row-actions">
              <button className="primary" onClick={() => decide(v.id, true)}><Check size={15}/> Approve</button>
              <button className="outline no" onClick={() => decide(v.id, false)}><X size={15}/> Reject</button>
            </div>
          </div>)}
    </div>}

    {tab === "projects" && <div className="panel">
      <div className="panel-head"><h3>Manage projects</h3><span className="badge ok">{store.projects.length} live</span></div>
      <div className="table">
        <div className="tr th five"><span>Project</span><span>Type</span><span>Location</span><span>Budget</span><span>Status</span></div>
        {store.projects.map(p => <div className="tr five" key={p.id}>
          <span><b>{p.title}</b></span><span>{p.type}</span><span>{p.location}</span><span>{p.budget}</span>
          <span><StatusPill status={p.status}/></span>
        </div>)}
      </div>
    </div>}

    {tab === "quotes" && <div className="panel">
      <div className="panel-head"><h3>Manage quotes</h3><span className="badge ok">{store.quotes.length} total</span></div>
      <div className="table">
        <div className="tr th four"><span>Quote ID</span><span>Project</span><span>Amount</span><span>Status</span></div>
        {store.quotes.map(q => {
          const p = store.projects.find(x => x.id === q.projectId);
          return <div className="tr four" key={q.id}>
            <span>#Q{String(q.id).padStart(4, "0")}</span>
            <span>{p ? p.title : "—"}</span>
            <span><b>₹{q.amount.toLocaleString("en-IN")}</b></span>
            <span><em className={`badge ${q.status === "Accepted" ? "ok" : "pending"}`}>{q.status}</em></span>
          </div>;
        })}
      </div>
    </div>}

    {tab === "reviews" && <div className="panel">
      <div className="panel-head"><h3>Manage reviews</h3><span className="badge pending">{reviews.filter(r => r.flagged).length} flagged</span></div>
      {reviews.map(r => <div className={`admin-row ${r.flagged ? "flagged" : ""}`} key={r.id}>
        <Avatar initials={r.by.slice(0, 2).toUpperCase()}/>
        <div><b>{r.by} → {r.about}</b><small>{r.text}</small>
          <div className="quote-flags">{r.flagged && <span className="flag warn"><Flag size={10}/> Flagged</span>}<span className="flag">{r.date}</span></div></div>
        <div className="row-actions">
          <Rating value={r.rating}/>
          <button className="outline no" onClick={() => { setReviews(reviews.filter(x => x.id !== r.id)); notify("Review removed"); }}><Trash2 size={14}/></button>
        </div>
      </div>)}
    </div>}

    {tab === "reports" && <>
      <div className="stats">
        <Stat icon={TrendingUp} label="Monthly growth" value="18"/>
        <Stat icon={Wallet} label="Value transacted" value="42"/>
        <Stat icon={Users} label="New sign-ups" value="96"/>
        <Stat icon={Star} label="Avg. platform rating" value="4.8" animate={false}/>
      </div>
      <div className="panel">
        <h3>Projects by category</h3>
        <div className="bars">
          {[["Interior Design", 78], ["New House", 54], ["Renovation", 32]].map(([label, v]) => (
            <div className="bar-row" key={label}>
              <small>{label}</small>
              <div className="bar"><div style={{ width: `${v}%` }}/></div>
              <b>{v}</b>
            </div>))}
        </div>
      </div>
      <div className="panel">
        <h3>Quotes by user type</h3>
        <div className="bars">
          {[["Professionals", 68], ["Students", 32]].map(([label, v]) => (
            <div className="bar-row" key={label}>
              <small>{label}</small>
              <div className="bar"><div style={{ width: `${v}%` }}/></div>
              <b>{v}%</b>
            </div>))}
        </div>
      </div>
    </>}

    {tab === "settings" && <div className="portal-grid">
      <div className="panel">
        <h3>App settings</h3>
        <div className="form">
          <Field label="Platform name"><input defaultValue="BuildNest"/></Field>
          <Field label="Support email"><input defaultValue="support@buildnest.in"/></Field>
          <Field label="Commission on completed projects"><input defaultValue="5%"/></Field>
        </div>
        <button className="primary" onClick={() => notify("Settings saved")}>Save settings</button>
      </div>
      <div className="panel">
        <h3>Controls</h3>
        {[["Require document verification", true], ["Allow student registrations", true], ["Auto-publish reviews", false], ["Maintenance mode", false]]
          .map(([label, on]) => <Toggle key={label} label={label} defaultOn={on} notify={notify}/>)}
      </div>
    </div>}
  </section>;
}

function Toggle({ label, defaultOn, notify }) {
  const [on, setOn] = useState(defaultOn);
  return <button className="toggle-row" onClick={() => { setOn(!on); notify(`${label} ${!on ? "enabled" : "disabled"}`); }}>
    <span>{label}</span><i className={on ? "switch on" : "switch"}/>
  </button>;
}
