import React, { useState } from "react";
import {
  ArrowRight, Award, BadgeCheck, Briefcase, Check, Clock3, FileText, FolderOpen,
  GraduationCap, Image as ImageIcon, MapPin, MessageCircle, Plus, Send, Sparkles,
  Star, TrendingUp, Upload, Wallet, X
} from "lucide-react";
import { Avatar, Stat, Rating, StatusPill, Modal, Field, EmptyState, SectionTitle, Verified } from "./ui.jsx";
import { openRequests, SOFTWARE, IMG, experts } from "./data.js";

/* ---------------- 11 / 15. DASHBOARD (Professional + Student) ---------------- */
export function PortalDashboard({ session, store, sendQuote, notify, nav }) {
  const isStudent = session.role === "Student";
  const myQuotes = store.sentQuotes;
  const [quoteFor, setQuoteFor] = useState(null);

  return <section className="section page-section">
    <SectionTitle
      eyebrow={isStudent ? "Student workspace" : "Professional workspace"}
      title={`Welcome back, ${session.name.split(" ")[0]}`}
      text={isStudent ? "Find real projects, build your portfolio and grow your experience." : "Track incoming requests, quotations and active work."}
      action={<Verified ok={!isStudent}/>}/>

    <div className="stats">
      <Stat icon={FileText} label="Open requests" value={String(openRequests.length)}/>
      <Stat icon={Send} label="Quotes sent" value={String(myQuotes.length)}/>
      <Stat icon={Clock3} label="Active projects" value={isStudent ? "1" : "3"}/>
      <Stat icon={isStudent ? TrendingUp : Wallet} label={isStudent ? "Portfolio views" : "Earnings this month"} value={isStudent ? "248" : "₹1,45,000"}/>
    </div>

    <div className="portal-grid">
      <div className="panel">
        <div className="panel-head"><h3>{isStudent ? "Available projects" : "New requests"}</h3><span className="badge ok">{openRequests.length} open</span></div>
        {openRequests.map(r => <div className="request-row" key={r.id}>
          <div className="project-icon small"><FileText size={17}/></div>
          <div className="request-main">
            <div className="request-title"><b>{r.title}</b><span className="fee">{r.serviceBudget}</span></div>
            <p className="muted"><MapPin size={13}/> {r.location} · {r.type} · {r.posted}</p>
          </div>
          <button className="outline" onClick={() => setQuoteFor(r)}>Send quote</button>
        </div>)}
      </div>

      <div className="panel">
        <h3>My quotations</h3>
        {myQuotes.length === 0
          ? <EmptyState icon={Send} title="No quotes sent yet" text="Pick a request and send your first offer."/>
          : myQuotes.map(q => <div className="admin-row" key={q.id}>
              <div className="stat-icon"><Wallet size={16}/></div>
              <div><b>{q.title}</b><small>₹{Number(q.amount).toLocaleString("en-IN")} · {q.duration}</small></div>
              <span className="badge pending">{q.status}</span>
            </div>)}
      </div>
    </div>

    <div className="portal-grid">
      <div className="panel">
        <h3>Recent messages</h3>
        {store.chats.slice(0, 3).map(c => <button className="admin-row link" key={c.id} onClick={() => nav("messages")}>
          <Avatar initials={c.initials}/>
          <div><b>{c.name}</b><small>{c.messages[c.messages.length - 1]?.text}</small></div>
          <MessageCircle size={16}/>
        </button>)}
      </div>
      <div className="panel">
        <h3>{isStudent ? "Portfolio growth" : "Profile performance"}</h3>
        <div className="activity"><b>{isStudent ? "3" : "12"}</b><span>{isStudent ? "academic projects uploaded" : "portfolio projects live"}</span></div>
        <div className="activity"><b>{isStudent ? "248" : "1,024"}</b><span>profile views this month</span></div>
        <div className="activity"><b>{isStudent ? "4.9" : "4.8"}</b><span>average rating</span></div>
        <button className="outline full" onClick={() => nav("portfolio")}><Upload size={16}/> Upload work</button>
      </div>
    </div>

    {quoteFor && <QuoteModal request={quoteFor} close={() => setQuoteFor(null)}
      submit={data => { sendQuote({ ...data, title: quoteFor.title }); setQuoteFor(null); notify("Quotation sent to customer"); }}/>}
  </section>;
}

/* ---------------- 14. QUOTATION MANAGEMENT ---------------- */
function QuoteModal({ request, close, submit }) {
  const [f, setF] = useState({ amount: "", duration: "", description: "", materials: "" });
  const set = (k, v) => setF(s => ({ ...s, [k]: v }));
  const ready = f.amount.trim() && f.duration.trim();
  return <Modal close={close}>
    <span className="eyebrow">Send quotation</span>
    <h2>{request.title}</h2>
    <p className="muted"><MapPin size={14}/> {request.location} · Customer budget {request.serviceBudget}</p>
    <div className="form two">
      <Field label="Your fee (₹)"><input value={f.amount} onChange={e => set("amount", e.target.value)} placeholder="25000"/></Field>
      <Field label="Timeline"><input value={f.duration} onChange={e => set("duration", e.target.value)} placeholder="e.g. 3 weeks"/></Field>
    </div>
    <Field label="What's included"><textarea value={f.description} onChange={e => set("description", e.target.value)} placeholder="Scope of work, deliverables, number of revisions..."/></Field>
    <Field label="Materials / assumptions"><textarea value={f.materials} onChange={e => set("materials", e.target.value)} placeholder="Materials, brands or assumptions behind this price"/></Field>
    <div className="modal-actions">
      <button className="outline" onClick={close}>Cancel</button>
      <button className="primary" disabled={!ready} onClick={() => submit(f)}>Send quotation <ArrowRight size={16}/></button>
    </div>
    {!ready && <p className="fineprint">Add a fee and timeline to send.</p>}
  </Modal>;
}

/* ---------------- 12 / 16. MANAGE PROFILE ---------------- */
export function ManageProfile({ session, notify }) {
  const isStudent = session.role === "Student";
  const [skills, setSkills] = useState(isStudent ? ["Space planning", "3D modelling"] : ["Floor plans", "Site supervision"]);
  const [software, setSoftware] = useState(["AutoCAD", "SketchUp"]);
  const [input, setInput] = useState("");
  const pool = isStudent ? [...SOFTWARE.Architecture, ...SOFTWARE.Interior] : [];

  const addSkill = () => { if (input.trim()) { setSkills([...skills, input.trim()]); setInput(""); } };
  const toggleSw = s => setSoftware(v => v.includes(s) ? v.filter(x => x !== s) : [...v, s]);

  return <section className="section page-section">
    <SectionTitle eyebrow={isStudent ? "Student profile" : "Professional profile"} title="Manage your profile"
      text="Everything here is what customers see before they send you work."
      action={<button className="primary" onClick={() => notify("Profile saved")}>Save changes</button>}/>

    <div className="portal-grid">
      <div className="panel">
        <h3>Basic details</h3>
        <div className="form two">
          <Field label="Display name"><input defaultValue={session.name}/></Field>
          <Field label="Phone"><input placeholder="+91 00000 00000"/></Field>
          <Field label="Location"><input placeholder="City / Area"/></Field>
          {isStudent
            ? <><Field label="College"><input placeholder="College name"/></Field>
                <Field label="Course"><select><option>B.Arch</option><option>B.Des (Interior)</option><option>Diploma in Architecture</option></select></Field>
                <Field label="Year"><select><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>Final Year</option></select></Field></>
            : <><Field label="Company"><input placeholder="Studio or firm name"/></Field>
                <Field label="Experience"><input placeholder="e.g. 8 yrs"/></Field>
                <Field label="Starting fee"><input placeholder="₹25,000"/></Field></>}
        </div>
        <Field label="About you"><textarea placeholder="Describe your approach, the projects you take on, and what makes your work different."/></Field>
      </div>

      <div className="side-col">
        <div className="panel">
          <h3>{isStudent ? "Skills" : "Services offered"}</h3>
          <div className="pill-list editable">
            {skills.map(s => <span key={s}>{s}<button onClick={() => setSkills(skills.filter(x => x !== s))} aria-label={`Remove ${s}`}><X size={11}/></button></span>)}
          </div>
          <div className="add-row">
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && addSkill()} placeholder={isStudent ? "Add a skill" : "Add a service"}/>
            <button className="outline" onClick={addSkill}><Plus size={15}/></button>
          </div>
        </div>

        {isStudent && <div className="panel">
          <h3>Software knowledge</h3>
          <div className="chips">{pool.map(s => <button className={software.includes(s) ? "chip on" : "chip"} key={s} onClick={() => toggleSw(s)}>{s}</button>)}</div>
        </div>}

        <div className="panel">
          <h3>Verification</h3>
          {isStudent
            ? <><p className="muted">Upload your college ID to get the student badge.</p><button className="outline full" onClick={() => notify("Document uploaded for review")}><Upload size={15}/> Upload college ID</button></>
            : <><p className="muted">Your licence and ID have been verified.</p><Verified ok/></>}
        </div>
      </div>
    </div>
  </section>;
}

/* ---------------- 13. UPLOAD PORTFOLIO ---------------- */
export function PortfolioPage({ session, notify }) {
  const isStudent = session.role === "Student";
  const [works, setWorks] = useState([
    { id: 1, title: isStudent ? "Low-cost Housing Studio" : "Coastal Villa", type: isStudent ? "Academic" : "New House", img: IMG.p1 },
    { id: 2, title: isStudent ? "Community Library" : "Row House Cluster", type: isStudent ? "Academic" : "New House", img: IMG.p2 },
    { id: 3, title: isStudent ? "Passive Cooling Study" : "Kitchen Remodel", type: isStudent ? "Academic" : "Renovation", img: IMG.p5 },
  ]);
  const [adding, setAdding] = useState(false);

  const add = f => {
    setWorks([...works, { id: Date.now(), title: f.title || "Untitled project", type: f.type, img: [IMG.p3, IMG.p4, IMG.p6, IMG.interior][works.length % 4] }]);
    setAdding(false); notify("Portfolio project added");
  };

  return <section className="section page-section">
    <SectionTitle eyebrow="Portfolio" title={isStudent ? "Academic & project work" : "Completed works"}
      text="Strong visuals win projects — upload images, drawings and finished spaces."
      action={<button className="primary" onClick={() => setAdding(true)}><Plus size={17}/> Add project</button>}/>

    <div className="work-grid">
      {works.map((w, i) => <figure className="work reveal-scale" style={{ "--d": `${i * 70}ms` }} key={w.id}>
        <div className="work-img" style={{ backgroundImage: `url(${w.img})` }}/>
        <figcaption><b>{w.title}</b><small>{w.type}</small></figcaption>
        <button className="work-del" onClick={() => setWorks(works.filter(x => x.id !== w.id))} aria-label="Remove"><X size={13}/></button>
      </figure>)}
      <button className="work add" onClick={() => setAdding(true)}><Plus size={24}/><b>Add project</b><small>Images, plans or renders</small></button>
    </div>

    {adding && <AddWork close={() => setAdding(false)} save={add} isStudent={isStudent}/>}
  </section>;
}

function AddWork({ close, save, isStudent }) {
  const [f, setF] = useState({ title: "", type: isStudent ? "Academic" : "New House", desc: "" });
  const set = (k, v) => setF(s => ({ ...s, [k]: v }));
  return <Modal close={close}>
    <span className="eyebrow">Upload portfolio</span>
    <h2>Add a project</h2>
    <div className="form two">
      <Field label="Project title"><input value={f.title} onChange={e => set("title", e.target.value)} placeholder="e.g. Coastal Villa"/></Field>
      <Field label="Project type"><select value={f.type} onChange={e => set("type", e.target.value)}>
        {(isStudent ? ["Academic", "Internship", "Competition", "Live project"] : ["New House", "Renovation", "Interior", "Construction"]).map(t => <option key={t}>{t}</option>)}
      </select></Field>
    </div>
    <Field label="Project details"><textarea value={f.desc} onChange={e => set("desc", e.target.value)} placeholder="Scope, area, materials, software used..."/></Field>
    <div className="upload-box"><ImageIcon size={26}/><b>Drop images here</b><p>Renders, drawings or site photos — JPG or PNG.</p><button className="outline">Choose images</button></div>
    <div className="modal-actions">
      <button className="outline" onClick={close}>Cancel</button>
      <button className="primary" onClick={() => save(f)}>Add to portfolio <ArrowRight size={16}/></button>
    </div>
  </Modal>;
}

/* ---------------- 17. EXPERIENCE SECTION ---------------- */
export function ExperiencePage({ session }) {
  const isStudent = session.role === "Student";
  const completed = [
    { title: "2BHK Interior Concept", client: "Neha B.", date: "Jun 2026", rating: 5, note: "Mood boards and 3D concepts delivered in 18 days." },
    { title: "Studio Apartment Layout", client: "Prasad M.", date: "Apr 2026", rating: 5, note: "Space planning for a 480 sq ft studio." },
  ];
  const internships = [
    { role: "Design Intern", org: "Meera Design Studio", period: "May – Jul 2025", note: "Worked on residential interiors and material sourcing." },
    { role: "Architecture Intern", org: "Rao & Associates", period: "Dec 2024 – Feb 2025", note: "Assisted with sanction drawings and site visits." },
  ];

  return <section className="section page-section">
    <SectionTitle eyebrow="Track record" title="Experience"
      text={isStudent ? "Completed projects, internships and the reviews you've earned." : "Completed projects and client feedback."}/>

    <div className="stats">
      <Stat icon={Check} label="Projects completed" value={String(completed.length)}/>
      <Stat icon={Star} label="Average rating" value="4.9" animate={false}/>
      <Stat icon={Briefcase} label="Internships" value={String(internships.length)}/>
      <Stat icon={Award} label="Repeat clients" value="2"/>
    </div>

    <div className="portal-grid">
      <div className="panel">
        <h3>Completed projects</h3>
        {completed.map(c => <div className="exp-row" key={c.title}>
          <div className="stat-icon"><Check size={16}/></div>
          <div><b>{c.title}</b><small>{c.client} · {c.date}</small><p className="muted">{c.note}</p></div>
          <Rating value={c.rating}/>
        </div>)}
      </div>

      {isStudent && <div className="panel">
        <h3>Internship work</h3>
        {internships.map(x => <div className="exp-row" key={x.org}>
          <div className="stat-icon"><GraduationCap size={16}/></div>
          <div><b>{x.role} — {x.org}</b><small>{x.period}</small><p className="muted">{x.note}</p></div>
        </div>)}
      </div>}
    </div>

    <div className="panel">
      <h3>Recent reviews</h3>
      <div className="review-list">
        {[{ by: "Neha B.", rating: 5, text: "Beautiful concepts at a student budget. Highly recommend.", date: "Jun 2026" },
          { by: "Prasad M.", rating: 5, text: "Fresh ideas and very quick with revisions.", date: "Apr 2026" }]
          .map((r, i) => <div className="review" key={i}>
            <Avatar initials={r.by.slice(0, 2).toUpperCase()}/>
            <div><div className="review-head"><b>{r.by}</b><Rating value={r.rating}/></div><p>{r.text}</p><small>{r.date}</small></div>
          </div>)}
      </div>
    </div>
  </section>;
}
