import React, { useState, useMemo } from "react";
import {
  ArrowRight, ArrowLeft, Building2, Check, Clock3, Compass, Construction, Filter,
  Heart, Home, Image as ImageIcon, MapPin, MessageCircle, Phone, Plus, Search,
  Send, Settings, ShieldCheck, Star, Users, Wallet, CreditCard, FileText, Sparkles
} from "lucide-react";
import {
  Avatar, CountUp, Rating, StatusPill, StatusTimeline, Modal, Field,
  EmptyState, SectionTitle, Stat, Verified
} from "./ui.jsx";
import { IMG, coverFor, experts, STATUSES, SOFTWARE } from "./data.js";

/* ---------------- 4. CUSTOMER DASHBOARD ---------------- */
export function CustomerHome({ nav, openExpert, newProject, store }) {
  const active = store.projects.filter(p => p.status !== "Completed").length;
  return <div>
    <section className="hero">
      <div className="hero-copy">
        <span className="eyebrow"><ShieldCheck size={14}/> Trusted local home experts</span>
        <h1>Find the right expert for your <em>dream home.</em></h1>
        <p>Connect with architects, contractors, interior designers and talented student designers — compare quotations and build with confidence.</p>
        <div className="hero-search"><Search/><input placeholder="Search architect, builder, designer..." onFocus={() => nav("experts")}/><button onClick={() => nav("experts")}>Search</button></div>
        <div className="hero-meta"><span><Check/> Verified profiles</span><span><Check/> Budget-friendly quotes</span><span><Check/> Local professionals</span></div>
      </div>
      <div className="hero-art">
        <div className="art-card art-photo">
          <div className="ph-img" style={{ backgroundImage: `url(${IMG.hero})` }}/>
          <div className="ph-frame"/>
          <div className="floating-card quote-float"><Wallet/><div><b>3 Quotes Received</b><small>Compare &amp; choose</small></div></div>
          <div className="floating-card verified-float"><ShieldCheck/><div><b>Verified Expert</b><small>4.9 ★ rating</small></div></div>
        </div>
      </div>
    </section>

    <section className="section">
      <div className="section-head reveal">
        <div><span className="eyebrow">Explore services</span><h2>Everything your home needs</h2></div>
        <button className="text-btn" onClick={() => nav("experts")}>View all <ArrowRight size={16}/></button>
      </div>
      <div className="category-grid">
        {[
          ["Architects", "Plan & design your home", Building2, "Architect", IMG.arch],
          ["Contractors", "Build with trusted crews", Construction, "Contractor", IMG.build],
          ["Interior Designers", "Create beautiful spaces", Compass, "Interior Designer", IMG.interior],
          ["Student Experts", "Fresh ideas, friendly budgets", Users, "Student", IMG.student],
        ].map(([title, desc, Icon, filter, img], i) => (
          <button className="category-card reveal-scale" style={{ "--d": `${i * 90}ms` }} key={filter} onClick={() => nav("experts", { filter })}>
            <div className="category-media" style={{ backgroundImage: `url(${img})` }}><div className="category-icon"><Icon/></div></div>
            <h3>{title}</h3><p>{desc}</p><ArrowRight size={17}/>
          </button>
        ))}
      </div>
    </section>

    {store.projects.length > 0 && <section className="section soft">
      <div className="section-head reveal">
        <div><span className="eyebrow">My workspace</span><h2>Your active projects</h2></div>
        <button className="text-btn" onClick={() => nav("projects")}>All projects <ArrowRight size={16}/></button>
      </div>
      <div className="mini-projects">
        {store.projects.slice(0, 3).map((p, i) => (
          <button className="mini-project reveal-scale" style={{ "--d": `${i * 80}ms` }} key={p.id} onClick={() => nav("track", { projectId: p.id })}>
            <div className="mini-top"><h3>{p.title}</h3><StatusPill status={p.status}/></div>
            <p className="muted"><MapPin size={13}/> {p.location} · {p.type}</p>
            <div className="progress"><div style={{ width: `${p.progress}%` }}/></div>
            <div className="mini-meta"><span>Budget <b>{p.budget}</b></span><span>{p.progress}%</span></div>
          </button>
        ))}
      </div>
    </section>}

    <Banner newProject={newProject} active={active}/>

    <section className="section">
      <div className="section-head reveal">
        <div><span className="eyebrow">Top rated</span><h2>Experts people trust</h2></div>
        <button className="text-btn" onClick={() => nav("experts")}>Browse experts <ArrowRight size={16}/></button>
      </div>
      <div className="expert-grid">{experts.slice(0, 4).map((e, i) => <ExpertCard key={e.id} expert={e} delay={i * 90} onClick={() => openExpert(e)}/>)}</div>
    </section>

    <section className="cta reveal" style={{ backgroundImage: `url(${IMG.cta})` }}>
      <div><span className="eyebrow">Start your project</span><h2>Have a home project in mind?</h2><p>Post your requirement and let suitable experts send you quotations.</p></div>
      <button className="primary large" onClick={newProject}>Post a project <ArrowRight size={18}/></button>
    </section>

    <section className="how section">
      <div className="section-head centered reveal"><div><span className="eyebrow">Simple process</span><h2>From dream to reality</h2></div></div>
      <div className="steps">
        {[["01", "Post", "Tell us about your home project."], ["02", "Compare", "Receive and compare quotations."],
          ["03", "Connect", "Chat directly with your chosen expert."], ["04", "Build", "Track progress until completion."]]
          .map((x, i) => <div className="step reveal" style={{ "--d": `${i * 110}ms` }} key={x[0]}><span>{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p></div>)}
      </div>
    </section>
  </div>;
}

function Banner({ newProject }) {
  return <section className="banner reveal">
    <div className="banner-media" style={{ backgroundImage: `url(${IMG.banner})` }}/>
    <div className="banner-inner">
      <span className="eyebrow light">Signature spaces</span>
      <h2>Where craftsmanship meets calm luxury.</h2>
      <p>From the first sketch to the final finish, BuildNest pairs you with vetted professionals who treat your home like their own.</p>
      <div className="banner-stats">
        <div><b><CountUp value="1,200"/>+</b><small>Homes designed</small></div>
        <div><b><CountUp value="320"/>+</b><small>Verified experts</small></div>
        <div><b><CountUp value="15"/></b><small>Cities served</small></div>
      </div>
      <button className="primary large" onClick={newProject}>Start your home <ArrowRight size={18}/></button>
    </div>
  </section>;
}

export function ExpertCard({ expert, onClick, delay = 0 }) {
  return <article className="expert-card reveal-scale" style={{ "--d": `${delay}ms` }}>
    <div className="expert-cover" style={{ backgroundImage: `url(${coverFor(expert.role)})` }}>
      <div className="expert-top"><Avatar initials={expert.initials} verified={expert.verified}/><button className="heart" aria-label="Save"><Heart size={17}/></button></div>
    </div>
    <div className="expert-info">
      <div className="role">{expert.role}</div><h3>{expert.name}</h3>
      <p className="muted"><MapPin size={14}/> {expert.location}</p>
      <Rating value={expert.rating} count={expert.reviews}/>
    </div>
    <div className="tags"><span>{expert.specialty}</span><span>{expert.experience}</span></div>
    <div className="card-bottom"><div><small>Starting from</small><b>{expert.price}</b></div><button className="outline" onClick={onClick}>View profile</button></div>
  </article>;
}

/* ---------------- 5. SEARCH & FILTER ---------------- */
export function SearchPage({ openExpert, preset }) {
  const [type, setType] = useState(preset?.filter || "All");
  const [userType, setUserType] = useState("All");
  const [location, setLocation] = useState("All");
  const [budget, setBudget] = useState("All");
  const [q, setQ] = useState("");

  const cities = ["All", ...new Set(experts.map(e => e.location))];
  const priceVal = p => parseFloat(p.replace(/[₹,+]/g, "")) * (p.includes("L") ? 100 : 1);

  const filtered = useMemo(() => experts.filter(e => {
    const okType = type === "All" || e.role.includes(type);
    const okUser = userType === "All" || (userType === "Student" ? e.type === "student" : e.type === "professional");
    const okCity = location === "All" || e.location === location;
    const v = priceVal(e.price);
    const okBudget = budget === "All" || (budget === "Low" ? v <= 10 : budget === "Medium" ? v > 10 && v <= 30 : v > 30);
    const okQ = `${e.name} ${e.role} ${e.location} ${e.specialty}`.toLowerCase().includes(q.toLowerCase());
    return okType && okUser && okCity && okBudget && okQ;
  }), [type, userType, location, budget, q]);

  const reset = () => { setType("All"); setUserType("All"); setLocation("All"); setBudget("All"); setQ(""); };

  return <section className="section page-section">
    <SectionTitle eyebrow="Expert marketplace" title="Find your home expert"
      text="Filter by service, user type, location and budget."
      action={<button className="outline" onClick={reset}><Filter size={16}/> Reset filters</button>}/>

    <div className="search-row">
      <div className="search-box"><Search/><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by name, service or location"/></div>
    </div>

    <div className="filter-bar">
      <FilterGroup label="Service type" value={type} set={setType} options={["All", "Architect", "Contractor", "Interior Designer"]}/>
      <FilterGroup label="User type" value={userType} set={setUserType} options={["All", "Professional", "Student"]}/>
      <FilterGroup label="Location" value={location} set={setLocation} options={cities}/>
      <FilterGroup label="Budget" value={budget} set={setBudget} options={["All", "Low", "Medium", "High"]}/>
    </div>

    <div className="result-line">{filtered.length} {filtered.length === 1 ? "expert" : "experts"} found <span>Sort: Recommended ▾</span></div>

    {filtered.length === 0
      ? <EmptyState icon={Search} title="No experts match those filters"
          text="Try widening the budget range or clearing the location filter."
          action={<button className="primary" onClick={reset}>Clear filters</button>}/>
      : <div className="expert-grid">{filtered.map((e, i) => <ExpertCard key={e.id} expert={e} delay={i * 80} onClick={() => openExpert(e)}/>)}</div>}
  </section>;
}

function FilterGroup({ label, value, set, options }) {
  return <div className="filter-group">
    <small>{label}</small>
    <div className="chips">{options.map(o => <button className={value === o ? "chip on" : "chip"} key={o} onClick={() => set(o)}>{o}</button>)}</div>
  </div>;
}

/* ---------------- 6. EXPERT / STUDENT PROFILE PAGE ---------------- */
export function ExpertProfile({ expert, back, notify, requestService, message }) {
  const [tab, setTab] = useState("portfolio");
  const isStudent = expert.type === "student";
  return <section className="section page-section">
    <button className="text-btn back" onClick={back}><ArrowLeft size={15}/> Back to experts</button>

    <div className="profile-banner" style={{ backgroundImage: `url(${coverFor(expert.role)})` }}>
      <div className="profile-banner-inner">
        <Avatar initials={expert.initials} verified={expert.verified} size={72}/>
        <div>
          <span className="role light">{expert.role}</span>
          <h1>{expert.name}</h1>
          <p><MapPin size={14}/> {expert.location} · {isStudent ? expert.college : expert.company}</p>
        </div>
        <div className="profile-banner-actions">
          <Verified ok={expert.verified}/>
          <Rating value={expert.rating} count={expert.reviews}/>
        </div>
      </div>
    </div>

    <div className="profile-key">
      {isStudent
        ? <><KeyBox label="College" value={expert.college}/><KeyBox label="Course" value={expert.course}/><KeyBox label="Year" value={expert.year}/><KeyBox label="Starting fee" value={expert.price}/></>
        : <><KeyBox label="Experience" value={expert.experience}/><KeyBox label="Specialization" value={expert.specialty}/><KeyBox label="Company" value={expert.company}/><KeyBox label="Starting fee" value={expert.price}/></>}
    </div>

    <div className="tabbar">
      {["portfolio", isStudent ? "skills" : "services", "reviews"].map(t =>
        <button className={tab === t ? "on" : ""} key={t} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>)}
    </div>

    {tab === "portfolio" && <>
      <p className="modal-copy">{expert.about}</p>
      <div className="work-grid">
        {expert.portfolio.map(w => <figure className="work" key={w.title}>
          <div className="work-img" style={{ backgroundImage: `url(${w.img})` }}/>
          <figcaption><b>{w.title}</b><small>{w.type}</small></figcaption>
        </figure>)}
      </div>
    </>}

    {tab === "services" && <div className="panel-grid">
      <div className="panel"><h3>Services offered</h3><div className="pill-list">{expert.services.map(s => <span key={s}>{s}</span>)}</div></div>
      {expert.styles?.length > 0 && <div className="panel"><h3>Interior styles</h3><div className="pill-list">{expert.styles.map(s => <span key={s}>{s}</span>)}</div></div>}
      {expert.materials?.length > 0 && <div className="panel"><h3>Materials handled</h3><div className="pill-list">{expert.materials.map(s => <span key={s}>{s}</span>)}</div></div>}
    </div>}

    {tab === "skills" && <div className="panel-grid">
      <div className="panel"><h3>Skills</h3><div className="pill-list">{expert.skills.map(s => <span key={s}>{s}</span>)}</div></div>
      <div className="panel"><h3>Software knowledge</h3><div className="pill-list">{expert.software.map(s => <span key={s}>{s}</span>)}</div></div>
      <div className="panel"><h3>Experience</h3>{(expert.internships || []).map(x => <div className="admin-row" key={x}><div className="stat-icon"><Sparkles size={16}/></div><div><b>{x}</b></div></div>)}</div>
    </div>}

    {tab === "reviews" && <div className="review-list">
      {expert.reviewList.map((r, i) => <div className="review" key={i}>
        <Avatar initials={r.by.slice(0, 2).toUpperCase()}/>
        <div><div className="review-head"><b>{r.by}</b><Rating value={r.rating}/></div><p>{r.text}</p><small>{r.date}</small></div>
      </div>)}
    </div>}

    <div className="profile-actions">
      <button className="outline" onClick={() => notify(`Calling ${expert.phone}`)}><Phone size={16}/> Call</button>
      <button className="outline" onClick={() => notify("Opening WhatsApp...")}><MessageCircle size={16}/> WhatsApp</button>
      <button className="outline" onClick={() => message(expert)}><Send size={16}/> Message</button>
      <button className="primary" onClick={() => requestService(expert)}>Request service <ArrowRight size={16}/></button>
    </div>
  </section>;
}

function KeyBox({ label, value }) {
  return <div className="key-box"><small>{label}</small><b>{value}</b></div>;
}

/* ---------------- 7. PROJECT CREATION ---------------- */
export function CreateProject({ close, submit }) {
  const [step, setStep] = useState(1);
  const [f, setF] = useState({
    type: "Interior Design", location: "", houseType: "2BHK", area: "",
    requirements: "", budget: "", serviceBudget: "", images: 0,
  });
  const set = (k, v) => setF(s => ({ ...s, [k]: v }));
  const canNext = step === 1 ? f.location.trim() : step === 2 ? f.budget.trim() : true;

  return <Modal close={close}>
    <span className="eyebrow">New project</span>
    <h2>Tell experts what you need</h2>
    <div className="modal-steps">
      <span className={step >= 1 ? "on" : ""}>1</span><i/><span className={step >= 2 ? "on" : ""}>2</span><i/><span className={step >= 3 ? "on" : ""}>3</span>
    </div>

    {step === 1 && <div className="form">
      <Field label="Project type"><select value={f.type} onChange={e => set("type", e.target.value)}><option>New House</option><option>Renovation</option><option>Interior Design</option></select></Field>
      <Field label="Project location"><input value={f.location} onChange={e => set("location", e.target.value)} placeholder="City / Area"/></Field>
      <Field label="House type"><select value={f.houseType} onChange={e => set("houseType", e.target.value)}><option>2BHK</option><option>3BHK</option><option>4BHK</option><option>Independent House</option></select></Field>
      <Field label="Built-up area"><input value={f.area} onChange={e => set("area", e.target.value)} placeholder="e.g. 1,200 sq ft"/></Field>
    </div>}

    {step === 2 && <div className="form">
      <Field label="Total project budget"><input value={f.budget} onChange={e => set("budget", e.target.value)} placeholder="₹20,00,000"/></Field>
      <Field label="Service budget (expert fee)"><input value={f.serviceBudget} onChange={e => set("serviceBudget", e.target.value)} placeholder="₹20,000"/></Field>
      <Field label="Requirements"><textarea value={f.requirements} onChange={e => set("requirements", e.target.value)} placeholder="Describe rooms, style preferences, must-haves..."/></Field>
    </div>}

    {step === 3 && <div className="upload-box" onClick={() => set("images", f.images + 1)}>
      <ImageIcon size={28}/><b>Add reference images</b>
      <p>Upload floor plans, inspiration images or photos of the existing space.</p>
      <button className="outline">Choose images</button>
      {f.images > 0 && <div className="upload-count"><Check size={14}/> {f.images} image{f.images > 1 ? "s" : ""} attached</div>}
    </div>}

    <div className="modal-actions">
      {step > 1 && <button className="outline" onClick={() => setStep(step - 1)}>Back</button>}
      <button className="primary" disabled={!canNext} onClick={() => step < 3 ? setStep(step + 1) : submit(f)}>
        {step < 3 ? "Continue" : "Submit request"} <ArrowRight size={16}/>
      </button>
    </div>
    {!canNext && <p className="fineprint">Add {step === 1 ? "a location" : "a budget"} to continue.</p>}
  </Modal>;
}

/* ---------------- 8. QUOTATION COMPARISON ---------------- */
export function QuotesPage({ store, accept, notify, nav }) {
  const withQuotes = store.projects.filter(p => store.quotes.some(q => q.projectId === p.id));
  const [pid, setPid] = useState(withQuotes[0]?.id ?? null);
  const project = store.projects.find(p => p.id === pid);
  const list = store.quotes.filter(q => q.projectId === pid);
  const [compare, setCompare] = useState([]);
  const toggle = id => setCompare(c => c.includes(id) ? c.filter(x => x !== id) : c.length >= 3 ? c : [...c, id]);
  const expertOf = id => experts.find(e => e.id === id);

  if (!project) return <section className="section page-section">
    <SectionTitle eyebrow="⭐ BuildNest feature" title="Quotation comparison"/>
    <EmptyState icon={Wallet} title="No quotations yet"
      text="Once you post a project, professionals and students send offers here to compare."
      action={<button className="primary" onClick={() => nav("projects")}>Go to my projects</button>}/>
  </section>;

  /* Normalise "20 days" / "6 weeks" / "1 month" to days so the fastest quote is picked correctly */
  const toDays = d => {
    const n = parseFloat(d) || 0;
    if (/month/i.test(d)) return n * 30;
    if (/week/i.test(d)) return n * 7;
    return n;
  };
  const cheapest = Math.min(...list.map(q => q.amount));
  const fastest = list.reduce((a, b) => (toDays(a.duration) <= toDays(b.duration) ? a : b), list[0]);

  return <section className="section page-section">
    <SectionTitle eyebrow="⭐ BuildNest feature" title="Quotation comparison"
      text="Compare price, timeline, experience and offer details before choosing."/>

    {withQuotes.length > 1 && <div className="chips space">
      {withQuotes.map(p => <button className={pid === p.id ? "chip on" : "chip"} key={p.id} onClick={() => { setPid(p.id); setCompare([]); }}>{p.title}</button>)}
    </div>}

    <div className="quote-project">
      <div><span className="mini-label">PROJECT</span><h2>{project.title}</h2>
        <p><MapPin size={14}/> {project.location} · {project.type} · Budget {project.budget}</p></div>
      <StatusPill status={project.status}/>
    </div>

    <div className="quote-table">
      <div className="quote-head"><span>Expert</span><span>Rating</span><span>Fee</span><span>Timeline</span><span></span></div>
      {list.map(q => {
        const e = expertOf(q.expertId);
        const won = project.awardedTo === q.expertId;
        return <div className={`quote-row ${compare.includes(q.id) ? "selected" : ""}`} key={q.id}>
          <div className="quote-person">
            <Avatar initials={e.initials} verified={e.verified}/>
            <div><b>{e.name}</b><small>{e.role}</small>
              <div className="quote-flags">
                {q.amount === cheapest && <span className="flag">Lowest fee</span>}
                {q.id === fastest.id && <span className="flag alt">Fastest</span>}
              </div>
            </div>
          </div>
          <Rating value={e.rating}/>
          <strong>₹{q.amount.toLocaleString("en-IN")}</strong>
          <span>{q.duration}</span>
          <div className="quote-cta">
            <button className={compare.includes(q.id) ? "primary" : "outline"} onClick={() => toggle(q.id)}>
              {compare.includes(q.id) ? <><Check size={15}/> Comparing</> : "Compare"}
            </button>
            {won
              ? <span className="badge ok"><Check size={12}/> Accepted</span>
              : project.awardedTo == null && <button className="outline accept" onClick={() => accept(project.id, q)}>Accept</button>}
          </div>
        </div>;
      })}
    </div>

    {compare.length > 0 && <div className="compare-grid">
      {compare.map(id => {
        const q = list.find(x => x.id === id), e = expertOf(q.expertId);
        return <div className="compare-card" key={id}>
          <div className="compare-head"><Avatar initials={e.initials} verified={e.verified}/><div><b>{e.name}</b><small>{e.role}</small></div></div>
          <dl>
            <div><dt>Fee</dt><dd>₹{q.amount.toLocaleString("en-IN")}</dd></div>
            <div><dt>Timeline</dt><dd>{q.duration}</dd></div>
            <div><dt>Rating</dt><dd>{e.rating} ★ ({e.reviews})</dd></div>
            <div><dt>Experience</dt><dd>{e.experience}</dd></div>
          </dl>
          <p className="modal-copy">{q.description}</p>
          <p className="fineprint">Materials: {q.materials}</p>
          {project.awardedTo == null && <button className="primary full" onClick={() => accept(project.id, q)}>Accept this quote</button>}
        </div>;
      })}
    </div>}

    <div className="quote-insight"><Wallet/><div><b>Smart comparison</b>
      <p>Cheapest isn't always best — weigh the fee against timeline, rating and what's actually included in the scope.</p></div></div>
  </section>;
}

/* ---------------- 10. PROJECT LIST + TRACKING ---------------- */
export function ProjectsPage({ store, newProject, nav }) {
  const done = store.projects.filter(p => p.status === "Completed").length;
  return <section className="section page-section">
    <SectionTitle eyebrow="My workspace" title="My projects" text="Track requests, quotations and ongoing work."
      action={<button className="primary" onClick={newProject}><Plus size={18}/> New project</button>}/>
    <div className="stats">
      <Stat icon={Compass} label="Total projects" value={String(store.projects.length)}/>
      <Stat icon={Wallet} label="Quotes received" value={String(store.quotes.length)}/>
      <Stat icon={Clock3} label="Active projects" value={String(store.projects.filter(p => p.status !== "Completed").length)}/>
      <Stat icon={Check} label="Completed" value={String(done)}/>
    </div>

    {store.projects.length === 0
      ? <EmptyState icon={Compass} title="No projects yet" text="Post your first requirement and experts will send you quotations."
          action={<button className="primary" onClick={newProject}><Plus size={16}/> Post a project</button>}/>
      : <div className="project-list">{store.projects.map((p, i) => (
          <article className="project-card reveal" style={{ "--d": `${i * 90}ms` }} key={p.id}>
            <div className="project-icon"><Home/></div>
            <div className="project-main">
              <div className="project-title">
                <div><h3>{p.title}</h3><p>{p.type} · <MapPin size={13}/>{p.location}</p></div>
                <StatusPill status={p.status}/>
              </div>
              <div className="progress"><div style={{ width: `${p.progress}%` }}/></div>
              <div className="project-meta">
                <span>Budget <b>{p.budget}</b></span>
                <span>Quotes <b>{store.quotes.filter(q => q.projectId === p.id).length}</b></span>
                <span>Progress <b>{p.progress}%</b></span>
                <button className="text-btn" onClick={() => nav("track", { projectId: p.id })}>Track project <ArrowRight size={15}/></button>
              </div>
            </div>
          </article>))}
        </div>}
  </section>;
}

export function TrackProject({ store, projectId, back, advance, notify, openReview, openPayment }) {
  const p = store.projects.find(x => x.id === projectId) || store.projects[0];
  if (!p) return null;
  const awarded = experts.find(e => e.id === p.awardedTo);
  const idx = STATUSES.indexOf(p.status);
  const nextStatus = STATUSES[idx + 1];

  return <section className="section page-section">
    <button className="text-btn back" onClick={back}><ArrowLeft size={15}/> Back to projects</button>
    <SectionTitle eyebrow="Project tracking" title={p.title} text={`${p.type} · ${p.location} · Posted ${p.createdAt}`}
      action={<StatusPill status={p.status}/>}/>

    <div className="panel track-panel"><StatusTimeline status={p.status}/></div>

    <div className="track-grid">
      <div className="panel">
        <h3>Project details</h3>
        <dl className="detail-list">
          <div><dt>House type</dt><dd>{p.houseType}</dd></div>
          <div><dt>Area</dt><dd>{p.area || "—"}</dd></div>
          <div><dt>Total budget</dt><dd>{p.budget}</dd></div>
          <div><dt>Service budget</dt><dd>{p.serviceBudget || "—"}</dd></div>
        </dl>
        <p className="modal-copy">{p.requirements}</p>
      </div>

      <div className="panel">
        <h3>Assigned expert</h3>
        {awarded
          ? <>
              <div className="admin-row"><Avatar initials={awarded.initials} verified={awarded.verified}/>
                <div><b>{awarded.name}</b><small>{awarded.role} · {awarded.location}</small></div></div>
              <div className="progress"><div style={{ width: `${p.progress}%` }}/></div>
              <p className="fineprint">{p.progress}% complete</p>
            </>
          : <p className="muted">No expert assigned yet. Accept a quotation to start work.</p>}
      </div>
    </div>

    <div className="panel">
      <h3>Progress updates</h3>
      <div className="updates">
        {p.updates.map((up, i) => <div className="update" key={i}><span className="dot"/><div><b>{up.date}</b><p>{up.text}</p></div></div>)}
      </div>
    </div>

    <div className="track-actions">
      {nextStatus && p.awardedTo && <button className="primary" onClick={() => advance(p.id)}>Mark as {nextStatus} <ArrowRight size={16}/></button>}
      {p.status === "Completed" && !p.review && <button className="outline" onClick={() => openReview(p)}><Star size={16}/> Leave a review</button>}
      {p.status === "Completed" && !p.paid && <button className="outline" onClick={() => openPayment(p)}><CreditCard size={16}/> Make payment</button>}
      {p.paid && <span className="badge ok"><Check size={12}/> Payment complete</span>}
      {p.review && <span className="badge ok"><Star size={12}/> Reviewed {p.review.rating}★</span>}
    </div>
  </section>;
}

/* ---------------- 14. REVIEW & RATING ---------------- */
export function ReviewModal({ project, close, save }) {
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");
  return <Modal close={close}>
    <span className="eyebrow">Review &amp; rating</span>
    <h2>How did it go?</h2>
    <p className="muted">Your feedback helps other homeowners choose well.</p>
    <div className="star-pick">
      {[1, 2, 3, 4, 5].map(n => <button key={n} className={n <= rating ? "on" : ""} onClick={() => setRating(n)} aria-label={`${n} star`}>
        <Star size={30} fill={n <= rating ? "currentColor" : "none"}/></button>)}
    </div>
    <Field label="Your review"><textarea value={text} onChange={e => setText(e.target.value)} placeholder="What went well? What could improve?"/></Field>
    <div className="modal-actions">
      <button className="outline" onClick={close}>Cancel</button>
      <button className="primary" onClick={() => save(project.id, { rating, text })}>Publish review <ArrowRight size={16}/></button>
    </div>
  </Modal>;
}

/* ---------------- 15. PAYMENT ---------------- */
export function PaymentModal({ project, close, pay }) {
  const [method, setMethod] = useState("UPI");
  return <Modal close={close}>
    <span className="eyebrow">Secure payment</span>
    <h2>Complete transaction</h2>
    <div className="pay-summary">
      <div><small>Project</small><b>{project.title}</b></div>
      <div><small>Agreed amount</small><b>{project.serviceBudget || project.budget}</b></div>
    </div>
    <div className="pay-methods">
      {["UPI", "Card", "Net banking"].map(m => <button className={method === m ? "chip on" : "chip"} key={m} onClick={() => setMethod(m)}>{m}</button>)}
    </div>
    <p className="fineprint">Payments are released as per the agreement between you and your expert. This is a prototype — no real transaction occurs.</p>
    <div className="modal-actions">
      <button className="outline" onClick={close}>Cancel</button>
      <button className="primary" onClick={() => pay(project.id)}>Pay via {method} <ArrowRight size={16}/></button>
    </div>
  </Modal>;
}

/* ---------------- 9. MESSAGING ---------------- */
export function MessagesPage({ store, send }) {
  const [active, setActive] = useState(0);
  const [draft, setDraft] = useState("");
  const chat = store.chats[active];
  const submit = () => { if (!draft.trim()) return; send(chat.id, draft.trim()); setDraft(""); };

  return <section className="section page-section">
    <SectionTitle eyebrow="Communication" title="Messages" text="Chat with professionals and keep project conversations together."/>
    <div className="chat">
      <aside>{store.chats.map((c, i) => <button className={active === i ? "chat-contact active" : "chat-contact"} onClick={() => setActive(i)} key={c.id}>
        <Avatar initials={c.initials}/>
        <div><b>{c.name}</b><small>{c.messages[c.messages.length - 1]?.text}</small></div>
        <time>{c.time}</time>
      </button>)}</aside>
      <div className="conversation">
        <div className="conversation-head">
          <Avatar initials={chat.initials}/>
          <div><b>{chat.name}</b><small>{chat.online ? "● Online" : "Offline"} · {chat.role}</small></div>
          <button className="icon-btn" aria-label="Settings"><Settings size={18}/></button>
        </div>
        <div className="messages">
          {chat.messages.map((m, i) => <div className={`bubble ${m.from}`} key={i}>{m.text}</div>)}
        </div>
        <div className="message-input">
          <button aria-label="Attach"><Plus size={18}/></button>
          <input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} placeholder="Write a message..."/>
          <button className="send" onClick={submit} aria-label="Send"><Send size={17}/></button>
        </div>
      </div>
    </div>
  </section>;
}
