import React, { useState, useRef, useEffect } from "react";
import { Check, MapPin, Star, X, ShieldCheck, Home } from "lucide-react";
import { STATUSES, statusClass } from "./data.js";

export const prefersReduced = () =>
  typeof window !== "undefined" && window.matchMedia &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* Reveals .reveal / .reveal-scale elements as they scroll into view. Re-runs when `dep` changes. */
export function useScrollReveal(dep) {
  useEffect(() => {
    const els = [...document.querySelectorAll(".reveal, .reveal-scale")]
      .filter(el => !el.classList.contains("is-visible"));
    if (prefersReduced() || !("IntersectionObserver" in window)) {
      els.forEach(el => el.classList.add("is-visible"));
      return;
    }
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) { en.target.classList.add("is-visible"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [dep]);
}

/* Counts up to a numeric value the first time it scrolls into view. */
export function CountUp({ value }) {
  const ref = useRef(null);
  const [txt, setTxt] = useState(String(value));
  useEffect(() => {
    const m = String(value).match(/^(\D*)([\d,]+)(.*)$/);
    if (!m) { setTxt(String(value)); return; }
    const prefix = m[1], target = parseInt(m[2].replace(/,/g, ""), 10), suffix = m[3];
    if (isNaN(target)) { setTxt(String(value)); return; }
    const fmt = n => prefix + n.toLocaleString("en-IN") + suffix;
    if (prefersReduced()) { setTxt(fmt(target)); return; }
    let started = false;
    const run = () => {
      if (started) return; started = true;
      const dur = 1100, t0 = performance.now();
      const tick = now => {
        const p = Math.min(1, (now - t0) / dur);
        setTxt(fmt(Math.round(target * (1 - Math.pow(1 - p, 3)))));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };
    if (!("IntersectionObserver" in window)) { run(); return; }
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && run()), { threshold: 0.4 });
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, [value]);
  return <span ref={ref}>{txt}</span>;
}

export function Logo({ compact = false }) {
  return <div className="logo">
    <div className="logo-mark"><Home size={compact ? 19 : 22} strokeWidth={2.5}/></div>
    {!compact && <div><strong>Build<span>Nest</span></strong><small>From Dream Home to Reality</small></div>}
  </div>;
}

export function Avatar({ initials, verified = false, size }) {
  const st = size ? { height: size, width: size, fontSize: Math.round(size / 3.4) } : undefined;
  return <div className="avatar-wrap">
    <div className="avatar" style={st}>{initials}</div>
    {verified && <span className="verified"><Check size={10}/></span>}
  </div>;
}

export function Stat({ icon: Icon, label, value, animate = true }) {
  return <div className="stat reveal-scale">
    <div className="stat-icon"><Icon size={18}/></div>
    <div><small>{label}</small><strong>{animate ? <CountUp value={value}/> : value}</strong></div>
  </div>;
}

export function Rating({ value, count }) {
  return <div className="rating"><Star size={14} fill="currentColor"/><b>{value}</b>{count != null && <span>({count} reviews)</span>}</div>;
}

export function StatusPill({ status }) {
  return <span className={`status ${statusClass(status)}`}>{status}</span>;
}

/* Horizontal lifecycle tracker — flow chart steps 7 → 13 */
export function StatusTimeline({ status }) {
  const i = Math.max(0, STATUSES.indexOf(status));
  return <div className="timeline">
    {STATUSES.map((s, n) => (
      <div className={`tl-step ${n < i ? "done" : ""} ${n === i ? "current" : ""}`} key={s}>
        <span className="tl-dot">{n < i ? <Check size={12}/> : n + 1}</span>
        <small>{s}</small>
        {n < STATUSES.length - 1 && <i className="tl-bar"/>}
      </div>
    ))}
  </div>;
}

export function Modal({ children, close, wide = false }) {
  useEffect(() => {
    const esc = e => e.key === "Escape" && close();
    window.addEventListener("keydown", esc);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", esc); document.body.style.overflow = ""; };
  }, [close]);
  return <div className="modal-backdrop" onClick={close}>
    <div className={wide ? "modal modal-wide" : "modal"} onClick={e => e.stopPropagation()}>
      <button className="modal-close" onClick={close} aria-label="Close"><X/></button>
      {children}
    </div>
  </div>;
}

export function Field({ label, children }) {
  return <label className="field">{label}{children}</label>;
}

export function EmptyState({ icon: Icon, title, text, action }) {
  return <div className="empty">
    <div className="empty-icon"><Icon size={26}/></div>
    <b>{title}</b><p>{text}</p>{action}
  </div>;
}

export function SectionTitle({ eyebrow, title, text, action }) {
  return <div className="page-title">
    <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1>{text && <p>{text}</p>}</div>
    {action}
  </div>;
}

export function Verified({ ok }) {
  return ok
    ? <span className="badge ok"><ShieldCheck size={12}/> Verified</span>
    : <span className="badge pending">Pending verification</span>;
}

export function MetaLine({ children }) {
  return <p className="muted meta-line"><MapPin size={14}/> {children}</p>;
}
