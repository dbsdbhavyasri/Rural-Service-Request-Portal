import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Bell, Briefcase, Check, ChevronDown, Compass, FolderOpen, Home, LayoutDashboard,
  LogOut, Menu, MessageCircle, Search, ShieldCheck, Sparkles, UserRound, Users, Wallet, X
} from "lucide-react";
import "./styles.css";

import { Logo, Avatar, useScrollReveal } from "./ui.jsx";
import { Splash, Onboarding, Auth } from "./auth.jsx";
import {
  CustomerHome, SearchPage, ExpertProfile, CreateProject, QuotesPage,
  ProjectsPage, TrackProject, MessagesPage, ReviewModal, PaymentModal
} from "./customer.jsx";
import { PortalDashboard, ManageProfile, PortfolioPage, ExperiencePage } from "./portal.jsx";
import { AdminPanel } from "./admin.jsx";
import { seedProjects, seedQuotes, seedChats, experts, STATUSES } from "./data.js";

/* Navigation per role — mirrors the four modules in the app architecture */
const NAV = {
  Customer: [["home", "Home", Home], ["experts", "Find experts", Search], ["projects", "Projects", Compass],
             ["quotes", "Quotations", Wallet], ["messages", "Messages", MessageCircle]],
  Professional: [["dashboard", "Dashboard", LayoutDashboard], ["portfolio", "Portfolio", FolderOpen],
                 ["experience", "Experience", Sparkles], ["messages", "Messages", MessageCircle],
                 ["manage", "My profile", UserRound]],
  Student: [["dashboard", "Dashboard", LayoutDashboard], ["portfolio", "Portfolio", FolderOpen],
            ["experience", "Experience", Sparkles], ["messages", "Messages", MessageCircle],
            ["manage", "My profile", UserRound]],
  Admin: [["admin", "Dashboard", ShieldCheck], ["projects", "Projects", Compass], ["messages", "Messages", MessageCircle]],
};

const HOME_FOR = { Customer: "home", Professional: "dashboard", Student: "dashboard", Admin: "admin" };

function App() {
  const [stage, setStage] = useState("splash");           // splash → onboarding → auth → app
  const [session, setSession] = useState(null);
  const [page, setPage] = useState("home");
  const [params, setParams] = useState({});
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [expert, setExpert] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [reviewFor, setReviewFor] = useState(null);
  const [payFor, setPayFor] = useState(null);

  /* ---- shared store (Projects · Quotations · Messages) ---- */
  const [store, setStore] = useState({
    projects: seedProjects, quotes: seedQuotes, chats: seedChats, sentQuotes: [],
  });

  useScrollReveal(page + stage);

  const notify = msg => { setToast(msg); setTimeout(() => setToast(""), 2600); };
  const nav = (p, extra = {}) => {
    setPage(p); setParams(extra); setExpert(null); setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const login = s => { setSession(s); setStage("app"); setPage(HOME_FOR[s.role]); notify(`Signed in as ${s.title}`); };
  const logout = () => { setSession(null); setStage("auth"); setPage("home"); };

  /* ---- store actions ---- */
  const addProject = f => {
    const id = Date.now();
    setStore(s => ({ ...s, projects: [{
      id, title: `${f.houseType} ${f.type}`, type: f.type, location: f.location || "Vijayawada",
      houseType: f.houseType, area: f.area, budget: f.budget || "—", serviceBudget: f.serviceBudget,
      status: "Request Sent", progress: 15, customer: session?.name || "You",
      requirements: f.requirements || "No additional notes.", createdAt: "Today",
      awardedTo: null, paid: false, review: null,
      updates: [{ date: "Today", text: "Requirement posted to the marketplace." }],
    }, ...s.projects] }));
    setShowCreate(false); notify("Project request submitted"); nav("projects");
  };

  const acceptQuote = (projectId, quote) => {
    setStore(s => ({
      ...s,
      quotes: s.quotes.map(q => q.id === quote.id ? { ...q, status: "Accepted" } : q),
      projects: s.projects.map(p => p.id === projectId ? {
        ...p, status: "Accepted", progress: 55, awardedTo: quote.expertId,
        updates: [...p.updates, { date: "Today", text: `Quote accepted — ${experts.find(e => e.id === quote.expertId)?.name}.` }],
      } : p),
    }));
    notify("Quotation accepted — expert notified");
  };

  const advance = projectId => {
    setStore(s => ({ ...s, projects: s.projects.map(p => {
      if (p.id !== projectId) return p;
      const next = STATUSES[Math.min(STATUSES.indexOf(p.status) + 1, STATUSES.length - 1)];
      const prog = { "Request Sent": 15, "Quote Received": 45, Accepted: 55, "Work Started": 75, Completed: 100 }[next];
      return { ...p, status: next, progress: prog, updates: [...p.updates, { date: "Today", text: `Status updated to ${next}.` }] };
    }) }));
    notify("Project status updated");
  };

  const saveReview = (projectId, review) => {
    setStore(s => ({ ...s, projects: s.projects.map(p => p.id === projectId ? { ...p, review } : p) }));
    setReviewFor(null); notify(`Review published — ${review.rating}★`);
  };

  const pay = projectId => {
    setStore(s => ({ ...s, projects: s.projects.map(p => p.id === projectId ? { ...p, paid: true } : p) }));
    setPayFor(null); notify("Payment completed");
  };

  const sendMessage = (chatId, text) => {
    setStore(s => ({ ...s, chats: s.chats.map(c => c.id === chatId ? { ...c, messages: [...c.messages, { from: "me", text }], time: "Now" } : c) }));
  };

  const sendQuote = data => {
    setStore(s => ({ ...s, sentQuotes: [{ id: Date.now(), status: "Sent", ...data }, ...s.sentQuotes] }));
  };

  const requestService = e => { setExpert(null); notify(`Service request sent to ${e.name}`); setShowCreate(true); };
  const messageExpert = e => { setExpert(null); nav("messages"); notify(`Chat opened with ${e.name}`); };

  /* ---- pre-app stages ---- */
  if (stage === "splash") return <Splash next={() => setStage("onboarding")}/>;
  if (stage === "onboarding") return <Onboarding done={() => setStage("auth")}/>;
  if (stage === "auth") return <Auth login={login} back={() => setStage("onboarding")}/>;

  const navItems = NAV[session.role];
  const initials = session.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div className="app">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileOpen(v => !v)} aria-label="Menu">{mobileOpen ? <X/> : <Menu/>}</button>
        <Logo/>
        <nav className={mobileOpen ? "nav open" : "nav"}>
          {navItems.map(([id, label, Icon]) => (
            <button key={id} className={page === id ? "active" : ""} onClick={() => nav(id)}><Icon size={17}/>{label}</button>
          ))}
        </nav>
        <div className="top-actions">
          <span className="role-tag">{session.title}</span>
          <button className="icon-btn" onClick={() => notify("No new notifications")} aria-label="Notifications"><Bell size={19}/><i/></button>
          <button className="profile-chip" onClick={() => nav(session.role === "Customer" ? "profile" : "manage")}>
            <Avatar initials={initials}/><span>{session.name}</span><ChevronDown size={15}/>
          </button>
          <button className="icon-btn" onClick={logout} title="Sign out" aria-label="Sign out"><LogOut size={17}/></button>
        </div>
      </header>

      <main className="page">
        {expert
          ? <ExpertProfile expert={expert} back={() => setExpert(null)} notify={notify}
              requestService={requestService} message={messageExpert}/>
          : <>
            {page === "home" && <CustomerHome nav={nav} openExpert={setExpert} newProject={() => setShowCreate(true)} store={store}/>}
            {page === "experts" && <SearchPage openExpert={setExpert} preset={params}/>}
            {page === "projects" && <ProjectsPage store={store} newProject={() => setShowCreate(true)} nav={nav}/>}
            {page === "track" && <TrackProject store={store} projectId={params.projectId} back={() => nav("projects")}
              advance={advance} notify={notify} openReview={setReviewFor} openPayment={setPayFor}/>}
            {page === "quotes" && <QuotesPage store={store} accept={acceptQuote} notify={notify} nav={nav}/>}
            {page === "messages" && <MessagesPage store={store} send={sendMessage}/>}
            {page === "profile" && <CustomerProfile session={session} store={store} notify={notify} nav={nav}/>}
            {page === "dashboard" && <PortalDashboard session={session} store={store} sendQuote={sendQuote} notify={notify} nav={nav}/>}
            {page === "manage" && <ManageProfile session={session} notify={notify}/>}
            {page === "portfolio" && <PortfolioPage session={session} notify={notify}/>}
            {page === "experience" && <ExperiencePage session={session}/>}
            {page === "admin" && <AdminPanel store={store} notify={notify}/>}
          </>}
      </main>

      {showCreate && <CreateProject close={() => setShowCreate(false)} submit={addProject}/>}
      {reviewFor && <ReviewModal project={reviewFor} close={() => setReviewFor(null)} save={saveReview}/>}
      {payFor && <PaymentModal project={payFor} close={() => setPayFor(null)} pay={pay}/>}
      {toast && <div className="toast"><Check size={17}/>{toast}</div>}

      {/* Mobile bottom navigation */}
      <nav className="bottom-nav">
        {navItems.slice(0, 4).map(([id, label, Icon]) => (
          <button key={id} className={page === id ? "on" : ""} onClick={() => nav(id)}>
            <Icon size={19}/><small>{label.split(" ")[0]}</small>
          </button>
        ))}
        <button className={page === "profile" || page === "manage" ? "on" : ""}
          onClick={() => nav(session.role === "Customer" ? "profile" : "manage")}>
          <UserRound size={19}/><small>Profile</small>
        </button>
      </nav>

      <footer>
        <Logo compact/>
        <span>© 2026 BuildNest · Smart Home Construction &amp; Design Marketplace</span>
        <span>Built for homeowners &amp; local experts</span>
      </footer>
    </div>
  );
}

/* Customer profile page */
function CustomerProfile({ session, store, notify, nav }) {
  const initials = session.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return <section className="section page-section">
    <div className="profile-hero">
      <Avatar initials={initials}/>
      <div><span className="eyebrow">Customer profile</span><h1>{session.name}</h1>
        <p><Compass size={14}/> Vijayawada, Andhra Pradesh · {session.title}</p></div>
      <button className="outline" onClick={() => notify("Profile editor opened")}>Edit profile</button>
    </div>
    <div className="profile-layout">
      <div className="panel reveal">
        <h3>Account summary</h3>
        <div className="activity"><b>{store.projects.length}</b><span>projects posted</span></div>
        <div className="activity"><b>{store.quotes.length}</b><span>quotations received</span></div>
        <div className="activity"><b>{store.projects.filter(p => p.status === "Completed").length}</b><span>projects completed</span></div>
        <button className="outline full" onClick={() => nav("projects")}>View my projects</button>
      </div>
      <div className="panel reveal" style={{ "--d": "120ms" }}>
        <h3>Profile completeness</h3>
        <div className="big-number">72%</div>
        <div className="progress"><div style={{ width: "72%" }}/></div>
        <p className="muted">Add a profile photo and project preferences to help experts quote accurately.</p>
      </div>
    </div>
  </section>;
}

createRoot(document.getElementById("root")).render(<App/>);
