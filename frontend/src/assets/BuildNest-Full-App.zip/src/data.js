/* ============================================================
   BuildNest — mock data layer
   Mirrors the database tables in the project architecture:
   Users · Professionals · Students · Projects · Quotations · Reviews
   ============================================================ */

const u = (id, w) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

export const IMG = {
  hero:     u("1600596542815-ffad4c1539a9", 1200),
  banner:   u("1600607687939-ce8a6c25118c", 1600),
  cta:      u("1512917774080-9991f1c4c750", 1600),
  arch:     u("1567767292278-a4f21aa2d36e", 800),
  build:    u("1541888946425-d81bb19240f5", 800),
  interior: u("1618221195710-dd6b41faaea6", 800),
  student:  u("1524758631624-e2822e304c36", 800),
  onboard1: u("1600585154340-be6161a56a0c", 900),
  onboard2: u("1616486338812-3dadae4b4ace", 900),
  onboard3: u("1552664730-d307ca884978", 900),
  p1: u("1600210492486-724fe5c67fb0", 600),
  p2: u("1600566753086-00f18fb6b3ea", 600),
  p3: u("1583608205776-bfd35f0d9f83", 600),
  p4: u("1600607687920-4e2a09cf159d", 600),
  p5: u("1585128792020-803d29415281", 600),
  p6: u("1616594039964-ae9021a400a0", 600),
};

export const coverFor = (role = "") =>
  /Interior/.test(role) ? IMG.interior :
  /Contractor/.test(role) ? IMG.build :
  /Student/.test(role) ? IMG.student : IMG.arch;

/* ---- Project lifecycle (flow chart steps 7 → 15) ---- */
export const STATUSES = ["Request Sent", "Quote Received", "Accepted", "Work Started", "Completed"];
export const statusClass = (s) => s.toLowerCase().replaceAll(" ", "-");

/* ---- Roles offered at registration (flow chart step 3) ---- */
export const ROLES = [
  { key: "Customer",   label: "Customer",    hint: "Home owner posting a project",       icon: "home" },
  { key: "Professional", label: "Professional", hint: "Architect · Contractor · Designer", icon: "briefcase" },
  { key: "Student",    label: "Student",     hint: "Student architect or designer",      icon: "cap" },
  { key: "Admin",      label: "Admin",       hint: "Platform management",                icon: "shield" },
];

export const PRO_SERVICES = ["Architect", "Contractor", "Interior Designer"];
export const STUDENT_COURSES = ["B.Arch", "B.Des (Interior)", "Diploma in Architecture", "M.Arch"];

export const SOFTWARE = {
  Architecture: ["AutoCAD", "Revit", "SketchUp", "Lumion", "Rhino"],
  Interior: ["3ds Max", "SketchUp", "V-Ray", "Photoshop", "Enscape"],
};

/* ---- Experts (Professionals + Students) ---- */
export const experts = [
  {
    id: 1, name: "Arjun Rao", role: "Architect", type: "professional",
    location: "Vijayawada", rating: 4.9, reviews: 42, experience: "8 yrs",
    specialty: "Modern Residential", price: "₹25k+", initials: "AR", verified: true,
    company: "Rao & Associates", phone: "+91 98480 11223",
    about: "Residential architect focused on climate-responsive homes for Andhra's coastal belt. Handles sanction drawings through to site supervision.",
    services: ["Floor plans", "3D elevation", "Sanction drawings", "Site supervision"],
    styles: [], materials: [],
    portfolio: [
      { title: "Coastal Villa", type: "New House", img: IMG.p1 },
      { title: "Row House Cluster", type: "New House", img: IMG.p2 },
      { title: "Hillside Residence", type: "New House", img: IMG.p3 },
    ],
    reviewList: [
      { by: "Suresh K.", rating: 5, text: "Plans were approved first time. Very responsive on site.", date: "Jul 2026" },
      { by: "Lakshmi P.", rating: 5, text: "Understood our vastu requirements without compromising the design.", date: "May 2026" },
    ],
  },
  {
    id: 2, name: "Meera Designs", role: "Interior Designer", type: "professional",
    location: "Hyderabad", rating: 4.8, reviews: 35, experience: "6 yrs",
    specialty: "Contemporary Interiors", price: "₹20k+", initials: "MD", verified: true,
    company: "Meera Design Studio", phone: "+91 90000 44556",
    about: "Turnkey interiors for apartments and villas. Known for warm, liveable contemporary palettes and honest material budgeting.",
    services: ["Space planning", "3D views", "Modular kitchen", "Turnkey execution"],
    styles: ["Contemporary", "Minimal", "Warm modern"], materials: [],
    portfolio: [
      { title: "2BHK Warm Modern", type: "Interior", img: IMG.interior },
      { title: "Kitchen Remodel", type: "Renovation", img: IMG.p5 },
      { title: "Living Room Refresh", type: "Interior", img: IMG.p4 },
    ],
    reviewList: [
      { by: "Anil R.", rating: 5, text: "Mood boards were spot on. Delivered ahead of schedule.", date: "Jun 2026" },
      { by: "Divya S.", rating: 4, text: "Great taste. Minor delay on the wardrobe shutters.", date: "Apr 2026" },
    ],
  },
  {
    id: 3, name: "Karthik BuildWorks", role: "Contractor", type: "professional",
    location: "Guntur", rating: 4.7, reviews: 28, experience: "10 yrs",
    specialty: "Residential Construction", price: "₹1.2L+", initials: "KB", verified: true,
    company: "BuildWorks Constructions", phone: "+91 94900 77881",
    about: "Civil contractor handling G+2 residential builds end to end, with in-house masonry and finishing crews.",
    services: ["Full construction", "Structural work", "Finishing", "Renovation"],
    styles: [], materials: ["RCC framed", "Red brick", "AAC block", "Vitrified tiling", "Waterproofing"],
    portfolio: [
      { title: "G+2 Independent House", type: "Construction", img: IMG.build },
      { title: "Duplex Shell", type: "Construction", img: IMG.p6 },
      { title: "Compound & Landscaping", type: "Construction", img: IMG.p2 },
    ],
    reviewList: [
      { by: "Ravi T.", rating: 5, text: "Site was clean and progress updates came weekly.", date: "Jun 2026" },
      { by: "Mahesh G.", rating: 4, text: "Solid work. Costing was transparent throughout.", date: "Feb 2026" },
    ],
  },
  {
    id: 4, name: "Ananya Varma", role: "Student Architect", type: "student",
    location: "Vijayawada", rating: 4.8, reviews: 14, experience: "Final Year",
    specialty: "Sustainable Design", price: "₹8k+", initials: "AV", verified: false,
    college: "SPA Vijayawada", course: "B.Arch", year: "Final Year", phone: "+91 91234 56780",
    about: "Final year architecture student focused on passive cooling and low-cost sustainable housing. Available for concept design and drafting support.",
    services: ["Concept design", "2D drafting", "3D modelling", "Presentation sheets"],
    skills: ["Passive design", "Site analysis", "Hand rendering"],
    software: ["AutoCAD", "Revit", "SketchUp", "Lumion"],
    styles: [], materials: [],
    portfolio: [
      { title: "Low-cost Housing Studio", type: "Academic", img: IMG.p3 },
      { title: "Community Library", type: "Academic", img: IMG.arch },
      { title: "Passive Cooling Study", type: "Academic", img: IMG.p1 },
    ],
    reviewList: [
      { by: "Prasad M.", rating: 5, text: "Fresh ideas and very quick with revisions.", date: "Jul 2026" },
    ],
    internships: ["Rao & Associates — 3 month internship, 2025"],
  },
  {
    id: 5, name: "Riya Studio", role: "Student Interior Designer", type: "student",
    location: "Visakhapatnam", rating: 4.9, reviews: 11, experience: "3rd Year",
    specialty: "Minimal Interiors", price: "₹6k+", initials: "RS", verified: false,
    college: "Andhra University", course: "B.Des (Interior)", year: "3rd Year", phone: "+91 93456 12309",
    about: "Interior design student specialising in small-space planning and mood boarding for budget-conscious homes.",
    services: ["Mood boards", "Space planning", "3D concepts", "Colour consulting"],
    skills: ["Space planning", "Colour theory", "Styling"],
    software: ["3ds Max", "SketchUp", "V-Ray", "Photoshop"],
    styles: ["Minimal", "Scandinavian"], materials: [],
    portfolio: [
      { title: "Studio Apartment Concept", type: "Academic", img: IMG.p4 },
      { title: "Café Interior Study", type: "Academic", img: IMG.p5 },
      { title: "Bedroom Mood Board", type: "Academic", img: IMG.interior },
    ],
    reviewList: [
      { by: "Neha B.", rating: 5, text: "Beautiful concepts at a student budget. Highly recommend.", date: "Jun 2026" },
    ],
    internships: ["Meera Design Studio — summer intern, 2025"],
  },
];

/* ---- Projects (Projects table) ---- */
export const seedProjects = [
  {
    id: 1, title: "2BHK Interior Design", type: "Interior Design", location: "Vijayawada",
    houseType: "2BHK", area: "1,150 sq ft", budget: "₹4,00,000", serviceBudget: "₹30,000",
    status: "Quote Received", progress: 45, customer: "BuildNest User",
    requirements: "Full interior for a 2BHK — living, two bedrooms and a modular kitchen. Prefer warm neutral palette.",
    createdAt: "12 Aug 2026", awardedTo: null, paid: false, review: null,
    updates: [{ date: "12 Aug", text: "Requirement posted to the marketplace." }, { date: "14 Aug", text: "3 quotations received." }],
  },
  {
    id: 2, title: "Independent House", type: "New House", location: "Guntur",
    houseType: "Independent House", area: "2,400 sq ft", budget: "₹20,00,000", serviceBudget: "₹1,20,000",
    status: "Work Started", progress: 68, customer: "BuildNest User",
    requirements: "G+1 independent house on a 200 sq yd plot. Need structural drawings and full construction.",
    createdAt: "02 Jun 2026", awardedTo: 3, paid: false, review: null,
    updates: [
      { date: "02 Jun", text: "Requirement posted." }, { date: "08 Jun", text: "Quote accepted — Karthik BuildWorks." },
      { date: "20 Jun", text: "Foundation completed." }, { date: "05 Aug", text: "First floor slab poured." },
    ],
  },
  {
    id: 3, title: "Kitchen Renovation", type: "Renovation", location: "Vijayawada",
    houseType: "3BHK", area: "180 sq ft", budget: "₹1,50,000", serviceBudget: "₹15,000",
    status: "Request Sent", progress: 15, customer: "BuildNest User",
    requirements: "Modular kitchen replacement with better storage and a breakfast counter.",
    createdAt: "15 Aug 2026", awardedTo: null, paid: false, review: null,
    updates: [{ date: "15 Aug", text: "Requirement posted to the marketplace." }],
  },
];

/* ---- Quotations (Quotations table) ---- */
export const seedQuotes = [
  { id: 1, projectId: 1, expertId: 2, amount: 30000, duration: "1 month", status: "Sent",
    description: "Complete 2BHK interior concept, 3D views and material guidance.",
    materials: "Plywood carcass, laminate finish, quartz counter." },
  { id: 2, projectId: 1, expertId: 5, amount: 10000, duration: "20 days", status: "Sent",
    description: "Modern concept with space planning, mood boards and 3D concepts.",
    materials: "Concept stage only — material list on approval." },
  { id: 3, projectId: 1, expertId: 1, amount: 42000, duration: "6 weeks", status: "Sent",
    description: "Architecture + interior coordination with detailed drawings.",
    materials: "Full BOQ provided with drawings." },
  { id: 4, projectId: 2, expertId: 3, amount: 120000, duration: "7 months", status: "Accepted",
    description: "Full construction of G+1 including structure and finishing.",
    materials: "RCC framed structure, red brick, vitrified tiles." },
];

/* ---- Marketplace requests visible to professionals & students ---- */
export const openRequests = [
  { id: 101, title: "3BHK Flat Interior", type: "Interior Design", location: "Vijayawada", budget: "₹6,00,000", serviceBudget: "₹45,000", posted: "2 hours ago", customer: "Sridhar N." },
  { id: 102, title: "Duplex Elevation Design", type: "New House", location: "Guntur", budget: "₹35,00,000", serviceBudget: "₹60,000", posted: "Yesterday", customer: "Padma R." },
  { id: 103, title: "Bathroom Renovation", type: "Renovation", location: "Hyderabad", budget: "₹2,00,000", serviceBudget: "₹18,000", posted: "2 days ago", customer: "Imran S." },
];

/* ---- Messaging ---- */
export const seedChats = [
  { id: 1, name: "Meera Designs", initials: "MD", role: "Interior Designer", time: "10:42 AM", online: true,
    messages: [
      { from: "them", text: "Hello! I reviewed your 2BHK requirement. I can prepare the initial concept and mood board." },
      { from: "me", text: "That sounds great. Can you also include a modern kitchen layout?" },
      { from: "them", text: "Absolutely. I'll include it in the proposal." },
    ] },
  { id: 2, name: "Arjun Rao", initials: "AR", role: "Architect", time: "Yesterday", online: false,
    messages: [
      { from: "them", text: "The revised floor plan is ready." },
      { from: "me", text: "Perfect, please share the PDF." },
    ] },
  { id: 3, name: "Riya Studio", initials: "RS", role: "Student Interior Designer", time: "Mon", online: true,
    messages: [
      { from: "them", text: "Thank you for considering my quote!" },
    ] },
];

/* ---- Admin ---- */
export const seedVerifications = [
  { id: 1, name: "Studio Aria", role: "Interior Designer", initials: "SA", submitted: "Today", docs: "GST · Portfolio · ID proof" },
  { id: 2, name: "Vikram Architects", role: "Architect", initials: "VA", submitted: "Today", docs: "COA licence · ID proof" },
  { id: 3, name: "Nisha Rao", role: "Student Architect", initials: "NR", submitted: "Yesterday", docs: "College ID · Portfolio" },
];

export const platformUsers = [
  { id: 1, name: "BuildNest User", role: "Customer", location: "Vijayawada", joined: "Jan 2026", status: "Active" },
  { id: 2, name: "Arjun Rao", role: "Architect", location: "Vijayawada", joined: "Feb 2026", status: "Verified" },
  { id: 3, name: "Meera Designs", role: "Interior Designer", location: "Hyderabad", joined: "Feb 2026", status: "Verified" },
  { id: 4, name: "Karthik BuildWorks", role: "Contractor", location: "Guntur", joined: "Mar 2026", status: "Verified" },
  { id: 5, name: "Ananya Varma", role: "Student Architect", location: "Vijayawada", joined: "Jun 2026", status: "Pending" },
  { id: 6, name: "Riya Studio", role: "Student Interior Designer", location: "Visakhapatnam", joined: "Jul 2026", status: "Pending" },
];

export const seedReviews = [
  { id: 1, by: "Suresh K.", about: "Arjun Rao", rating: 5, text: "Plans approved first time. Very responsive.", date: "Jul 2026", flagged: false },
  { id: 2, by: "Anil R.", about: "Meera Designs", rating: 5, text: "Mood boards were spot on.", date: "Jun 2026", flagged: false },
  { id: 3, by: "Anonymous", about: "Karthik BuildWorks", rating: 2, text: "Delayed by two weeks without notice.", date: "Jun 2026", flagged: true },
];

export const onboarding = [
  { title: "Find trusted home experts", text: "Verified architects, contractors and interior designers near you — with real portfolios and honest ratings.", img: IMG.onboard1 },
  { title: "Design your dream space", text: "Post your requirement once, then compare quotations on price, timeline and experience side by side.", img: IMG.onboard2 },
  { title: "Connect with upcoming designers", text: "Give talented student architects and designers real projects, and get fresh ideas at a friendly budget.", img: IMG.onboard3 },
];
