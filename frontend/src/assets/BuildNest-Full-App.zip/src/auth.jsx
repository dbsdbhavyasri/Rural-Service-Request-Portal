import React, { useState, useEffect } from "react";
import {
  ArrowRight, ArrowLeft, Briefcase, GraduationCap, Home, ShieldCheck,
  Mail, Lock, Phone, MapPin, User, Building2
} from "lucide-react";
import { Logo, Field } from "./ui.jsx";
import { onboarding, ROLES, PRO_SERVICES, STUDENT_COURSES, IMG } from "./data.js";

const ROLE_ICON = { home: Home, briefcase: Briefcase, cap: GraduationCap, shield: ShieldCheck };

/* 1. SPLASH SCREEN */
export function Splash({ next }) {
  return <div className="splash">
    <div className="splash-glow"/>
    <div className="splash-inner">
      <div className="splash-logo"><Logo/></div>
      <h1>From Dream Home<br/><em>to Reality.</em></h1>
      <p>India's marketplace for architects, contractors, interior designers — and the students shaping what comes next.</p>
      <button className="primary large" onClick={next}>Get started <ArrowRight size={18}/></button>
    </div>
  </div>;
}

/* 2. ONBOARDING SCREENS */
export function Onboarding({ done }) {
  const [i, setI] = useState(0);
  const last = i === onboarding.length - 1;
  const slide = onboarding[i];
  return <div className="onboard">
    <button className="skip" onClick={done}>Skip</button>
    <div className="onboard-art" key={i}>
      <div className="onboard-img" style={{ backgroundImage: `url(${slide.img})` }}/>
    </div>
    <div className="onboard-copy" key={`c${i}`}>
      <span className="eyebrow">Step {i + 1} of {onboarding.length}</span>
      <h2>{slide.title}</h2>
      <p>{slide.text}</p>
      <div className="dots">{onboarding.map((_, n) => <i className={n === i ? "on" : ""} key={n} onClick={() => setI(n)}/>)}</div>
      <div className="onboard-actions">
        {i > 0 && <button className="outline" onClick={() => setI(i - 1)}><ArrowLeft size={16}/> Back</button>}
        <button className="primary large" onClick={() => last ? done() : setI(i + 1)}>
          {last ? "Continue" : "Next"} <ArrowRight size={18}/>
        </button>
      </div>
    </div>
  </div>;
}

/* 3. LOGIN / REGISTRATION */
export function Auth({ login, back }) {
  const [mode, setMode] = useState("register");
  const [role, setRole] = useState("Customer");
  const [service, setService] = useState(PRO_SERVICES[0]);
  const [course, setCourse] = useState(STUDENT_COURSES[0]);
  const [name, setName] = useState("");

  const submit = () => {
    const display = name.trim() || (mode === "login" ? "BuildNest User" : "New Member");
    let title = role;
    if (role === "Professional") title = service;
    if (role === "Student") title = course.includes("Interior") ? "Student Interior Designer" : "Student Architect";
    login({ role, title, name: display });
  };

  return <div className="auth">
    <div className="auth-visual" style={{ backgroundImage: `url(${IMG.hero})` }}>
      <div className="auth-visual-inner">
        <Logo/>
        <h2>Build with people you can actually verify.</h2>
        <ul className="auth-points">
          <li><ShieldCheck size={16}/> Documents checked before a profile goes live</li>
          <li><ShieldCheck size={16}/> Compare quotes before you commit a rupee</li>
          <li><ShieldCheck size={16}/> Students get real projects, you get fresh ideas</li>
        </ul>
      </div>
    </div>

    <div className="auth-form">
      <button className="text-btn back" onClick={back}><ArrowLeft size={15}/> Back</button>
      <div className="auth-tabs">
        <button className={mode === "register" ? "on" : ""} onClick={() => setMode("register")}>Create account</button>
        <button className={mode === "login" ? "on" : ""} onClick={() => setMode("login")}>Sign in</button>
      </div>

      <h1>{mode === "register" ? "Join BuildNest" : "Welcome back"}</h1>
      <p className="muted">{mode === "register" ? "Choose how you'll use the platform." : "Sign in to pick up where you left off."}</p>

      <div className="role-cards">
        {ROLES.map(r => {
          const Icon = ROLE_ICON[r.icon];
          return <button className={`role-card ${role === r.key ? "on" : ""}`} key={r.key} onClick={() => setRole(r.key)}>
            <Icon size={19}/><b>{r.label}</b><small>{r.hint}</small>
          </button>;
        })}
      </div>

      <div className="form two">
        {mode === "register" && <Field label="Full name"><input value={name} onChange={e => setName(e.target.value)} placeholder="Your name"/></Field>}
        <Field label="Email"><input type="email" placeholder="you@example.com"/></Field>
        {mode === "register" && <Field label="Phone"><input placeholder="+91 00000 00000"/></Field>}
        <Field label="Password"><input type="password" placeholder="••••••••"/></Field>
        {mode === "register" && <Field label="Location"><input placeholder="City / Area"/></Field>}

        {mode === "register" && role === "Professional" && <>
          <Field label="Service type"><select value={service} onChange={e => setService(e.target.value)}>{PRO_SERVICES.map(s => <option key={s}>{s}</option>)}</select></Field>
          <Field label="Company name"><input placeholder="Studio or firm name"/></Field>
          <Field label="Experience"><input placeholder="e.g. 6 yrs"/></Field>
        </>}

        {mode === "register" && role === "Student" && <>
          <Field label="College"><input placeholder="College name"/></Field>
          <Field label="Course"><select value={course} onChange={e => setCourse(e.target.value)}>{STUDENT_COURSES.map(c => <option key={c}>{c}</option>)}</select></Field>
          <Field label="Year"><select><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>Final Year</option></select></Field>
          <Field label="Skills"><input placeholder="AutoCAD, SketchUp, rendering..."/></Field>
        </>}
      </div>

      <button className="primary large full" onClick={submit}>
        {mode === "register" ? "Create account" : "Sign in"} <ArrowRight size={18}/>
      </button>
      <p className="fineprint">This is a prototype — any details you enter open a demo account for the role you picked.</p>
    </div>
  </div>;
}
