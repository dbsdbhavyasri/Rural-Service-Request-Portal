# BuildNest — Smart Home Construction & Design Marketplace

React + Vite frontend implementing the full BuildNest application architecture.

## Run
1. Install Node.js 18+
2. `npm install`
3. `npm run dev`
4. Open the local Vite URL shown in the terminal

## Screen map (matches the project flow chart)

| # | Screen | Where |
|---|--------|-------|
| 1 | Splash screen | `auth.jsx` → `Splash` |
| 2 | Onboarding (3 slides) | `auth.jsx` → `Onboarding` |
| 3 | Login / Registration + role choice | `auth.jsx` → `Auth` |
| 4 | Customer dashboard | `customer.jsx` → `CustomerHome` |
| 5 | Search & filter (service / user type / location / budget) | `customer.jsx` → `SearchPage` |
| 6 | Expert & student profile (role-specific tabs) | `customer.jsx` → `ExpertProfile` |
| 7 | Create project request (3 steps) | `customer.jsx` → `CreateProject` |
| 8 | Quotation comparison ⭐ | `customer.jsx` → `QuotesPage` |
| 9 | Messaging | `customer.jsx` → `MessagesPage` |
| 10 | Project tracking + status timeline | `customer.jsx` → `TrackProject` |
| 11 | Professional dashboard | `portal.jsx` → `PortalDashboard` |
| 12 | Manage profile | `portal.jsx` → `ManageProfile` |
| 13 | Upload portfolio | `portal.jsx` → `PortfolioPage` |
| 14 | Quotation management (send quote) | `portal.jsx` → `QuoteModal` |
| 15 | Student dashboard | `portal.jsx` → `PortalDashboard` |
| 16 | Student profile (college, skills, software) | `portal.jsx` → `ManageProfile` |
| 17 | Experience section | `portal.jsx` → `ExperiencePage` |
| 18 | Admin panel (8 tabs) | `admin.jsx` → `AdminPanel` |
| — | Review & rating | `customer.jsx` → `ReviewModal` |
| — | Payment | `customer.jsx` → `PaymentModal` |

## File structure
- `src/data.js` — mock data mirroring the DB tables (Users, Professionals, Students, Projects, Quotations, Reviews)
- `src/ui.jsx` — shared components + animation helpers (scroll reveal, count-up, timeline)
- `src/auth.jsx` — splash, onboarding, login/registration
- `src/customer.jsx` — customer module
- `src/portal.jsx` — professional + student modules
- `src/admin.jsx` — admin module
- `src/main.jsx` — app shell, role-based navigation, shared state
- `src/styles.css` — all styling

## Demo tips (viva)
- Register as **Customer** to walk the full journey: post a project → compare quotes → accept → track → review → pay.
- Sign out (top-right) and register as **Professional** or **Student** to see the other side: incoming requests → send quotation → portfolio.
- Register as **Admin** to demo verification approval, user management and reports.
- State is shared live: accepting a quote updates the project status, timeline and assigned expert instantly.

This prototype uses mock data and local React state. Connect the screens to the Python/MySQL backend later.
